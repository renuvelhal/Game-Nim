import numpy as np

radius=3
proximityMatrix = np.ones((radius, radius))*3
print(np.matrix(proximityMatrix))
